from __future__ import print_function
import json
from ibm_watson import AssistantV2

Password = '2CBcsXu   MZOQJbjRvwWuA37ydEV'
Assistant_ID = '869e16b1-   360-4ee93162d2b3'

assistant = AssistantV2(
    version='2018-09-20',
        url='https://gateway-lon.watsonplatform.net/assistant/api',
    iam_apikey=Password)

session = assistant.create_session(Assistant_ID).get_result()
print(json.dumps(session, indent=2))
session_id=session["session_id"]

message = assistant.message(
Assistant_ID,
session_id,
input={'text': 'Hello'},
).get_result()
print(json.dumps(message, indent=2))

assistant.delete_session(Assistant_ID, session_id).get_result()
